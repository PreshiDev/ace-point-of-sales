This project is not intended to be shared, so it is not in exe file/format, to convert to exe file, you need microsoft visual studio
