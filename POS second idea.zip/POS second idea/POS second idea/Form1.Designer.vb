﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.label4 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.SalesreportBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PointofsalesDataSet = New POS_second_idea.pointofsalesDataSet()
        Me.Sales_reportTableAdapter = New POS_second_idea.pointofsalesDataSetTableAdapters.sales_reportTableAdapter()
        Me.PointofsalesDataSet1 = New POS_second_idea.pointofsalesDataSet1()
        Me.SalesreportBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Sales_reportTableAdapter1 = New POS_second_idea.pointofsalesDataSet1TableAdapters.sales_reportTableAdapter()
        Me.PointofsalesDataSet2 = New POS_second_idea.pointofsalesDataSet2()
        Me.SalesreportBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Sales_reportTableAdapter2 = New POS_second_idea.pointofsalesDataSet2TableAdapters.sales_reportTableAdapter()
        Me.UpdateOrderOptionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Items = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Qunti = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Amount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ItemsList = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amounts = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.SalesreportBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PointofsalesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PointofsalesDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SalesreportBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PointofsalesDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SalesreportBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpdateOrderOptionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Button12)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button11)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button10)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button9)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Location = New System.Drawing.Point(2, 91)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(336, 440)
        Me.Panel1.TabIndex = 0
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(213, 326)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(99, 107)
        Me.Button12.TabIndex = 23
        Me.Button12.Text = "c"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(104, 222)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(99, 98)
        Me.Button4.TabIndex = 19
        Me.Button4.Text = "2"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(104, 27)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(103, 88)
        Me.Button11.TabIndex = 13
        Me.Button11.Text = "8"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(104, 121)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(103, 92)
        Me.Button3.TabIndex = 16
        Me.Button3.Text = "5"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(8, 121)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(90, 92)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "6"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(112, 326)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(95, 107)
        Me.Button10.TabIndex = 22
        Me.Button10.Text = "."
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(8, 222)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(90, 98)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "3"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(209, 222)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(103, 98)
        Me.Button6.TabIndex = 20
        Me.Button6.Text = "1"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(8, 27)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(90, 88)
        Me.Button9.TabIndex = 12
        Me.Button9.Text = "7"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(209, 121)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(103, 92)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "4"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(8, 326)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(98, 107)
        Me.Button8.TabIndex = 21
        Me.Button8.Text = "0"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(209, 27)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(103, 88)
        Me.Button7.TabIndex = 14
        Me.Button7.Text = "9"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.Button36)
        Me.Panel2.Controls.Add(Me.Button26)
        Me.Panel2.Controls.Add(Me.Button35)
        Me.Panel2.Controls.Add(Me.Button39)
        Me.Panel2.Controls.Add(Me.Button25)
        Me.Panel2.Controls.Add(Me.Button38)
        Me.Panel2.Controls.Add(Me.Button34)
        Me.Panel2.Controls.Add(Me.Button27)
        Me.Panel2.Controls.Add(Me.Button15)
        Me.Panel2.Controls.Add(Me.Button33)
        Me.Panel2.Controls.Add(Me.Button22)
        Me.Panel2.Controls.Add(Me.Button28)
        Me.Panel2.Controls.Add(Me.Button14)
        Me.Panel2.Controls.Add(Me.Button32)
        Me.Panel2.Controls.Add(Me.Button19)
        Me.Panel2.Controls.Add(Me.Button13)
        Me.Panel2.Controls.Add(Me.Button17)
        Me.Panel2.Controls.Add(Me.Button29)
        Me.Panel2.Controls.Add(Me.Button31)
        Me.Panel2.Controls.Add(Me.Button30)
        Me.Panel2.Location = New System.Drawing.Point(714, 91)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(672, 441)
        Me.Panel2.TabIndex = 0
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.White
        Me.Label23.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(513, 388)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(94, 26)
        Me.Label23.TabIndex = 28
        Me.Label23.Text = "N 1600"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.White
        Me.Label22.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(513, 283)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(94, 26)
        Me.Label22.TabIndex = 27
        Me.Label22.Text = "N 2000"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.White
        Me.Label21.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(509, 205)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(94, 26)
        Me.Label21.TabIndex = 26
        Me.Label21.Text = "N 2350"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.White
        Me.Label20.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(509, 121)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(94, 26)
        Me.Label20.TabIndex = 25
        Me.Label20.Text = "N 3960"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.White
        Me.Label19.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(513, 45)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(94, 26)
        Me.Label19.TabIndex = 24
        Me.Label19.Text = "N 2500"
        '
        'Button36
        '
        Me.Button36.BackgroundImage = CType(resources.GetObject("Button36.BackgroundImage"), System.Drawing.Image)
        Me.Button36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button36.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.ForeColor = System.Drawing.Color.Blue
        Me.Button36.Location = New System.Drawing.Point(336, 336)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(118, 79)
        Me.Button36.TabIndex = 23
        Me.Button36.Text = "N: 850"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.BackgroundImage = CType(resources.GetObject("Button26.BackgroundImage"), System.Drawing.Image)
        Me.Button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button26.Font = New System.Drawing.Font("Algerian", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Button26.Location = New System.Drawing.Point(188, 5)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(110, 80)
        Me.Button26.TabIndex = 13
        Me.Button26.Text = "N: 950"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.BackgroundImage = CType(resources.GetObject("Button35.BackgroundImage"), System.Drawing.Image)
        Me.Button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button35.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button35.ForeColor = System.Drawing.Color.Yellow
        Me.Button35.Location = New System.Drawing.Point(188, 335)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(111, 79)
        Me.Button35.TabIndex = 22
        Me.Button35.Text = "N: 400"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.BackgroundImage = CType(resources.GetObject("Button39.BackgroundImage"), System.Drawing.Image)
        Me.Button39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button39.Location = New System.Drawing.Point(501, 5)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(115, 77)
        Me.Button39.TabIndex = 12
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.BackgroundImage = CType(resources.GetObject("Button25.BackgroundImage"), System.Drawing.Image)
        Me.Button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button25.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.ForeColor = System.Drawing.SystemColors.GrayText
        Me.Button25.Location = New System.Drawing.Point(32, 3)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(115, 77)
        Me.Button25.TabIndex = 12
        Me.Button25.Text = "N: 150"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.BackgroundImage = CType(resources.GetObject("Button38.BackgroundImage"), System.Drawing.Image)
        Me.Button38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button38.Location = New System.Drawing.Point(499, 336)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(117, 79)
        Me.Button38.TabIndex = 21
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.BackgroundImage = CType(resources.GetObject("Button34.BackgroundImage"), System.Drawing.Image)
        Me.Button34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button34.Font = New System.Drawing.Font("Algerian", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.Location = New System.Drawing.Point(30, 335)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(117, 79)
        Me.Button34.TabIndex = 21
        Me.Button34.Text = "N: 1,250"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.BackgroundImage = CType(resources.GetObject("Button27.BackgroundImage"), System.Drawing.Image)
        Me.Button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button27.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.ForeColor = System.Drawing.SystemColors.Info
        Me.Button27.Location = New System.Drawing.Point(336, 5)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(118, 80)
        Me.Button27.TabIndex = 14
        Me.Button27.Text = "N: 1600"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.BackgroundImage = CType(resources.GetObject("Button15.BackgroundImage"), System.Drawing.Image)
        Me.Button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button15.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(334, 252)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(120, 68)
        Me.Button15.TabIndex = 20
        Me.Button15.Text = "N: 500"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.BackgroundImage = CType(resources.GetObject("Button33.BackgroundImage"), System.Drawing.Image)
        Me.Button33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button33.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.Location = New System.Drawing.Point(336, 171)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(118, 77)
        Me.Button33.TabIndex = 20
        Me.Button33.Text = "N: 500"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.BackgroundImage = CType(resources.GetObject("Button22.BackgroundImage"), System.Drawing.Image)
        Me.Button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button22.Location = New System.Drawing.Point(499, 86)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(117, 77)
        Me.Button22.TabIndex = 15
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.BackgroundImage = CType(resources.GetObject("Button28.BackgroundImage"), System.Drawing.Image)
        Me.Button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button28.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.Location = New System.Drawing.Point(30, 88)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(117, 75)
        Me.Button28.TabIndex = 15
        Me.Button28.Text = "N: 125"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.BackgroundImage = CType(resources.GetObject("Button14.BackgroundImage"), System.Drawing.Image)
        Me.Button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button14.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button14.Location = New System.Drawing.Point(188, 252)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(111, 68)
        Me.Button14.TabIndex = 19
        Me.Button14.Text = "N: 280"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.BackgroundImage = CType(resources.GetObject("Button32.BackgroundImage"), System.Drawing.Image)
        Me.Button32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button32.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button32.ForeColor = System.Drawing.Color.ForestGreen
        Me.Button32.Location = New System.Drawing.Point(188, 169)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(110, 77)
        Me.Button32.TabIndex = 19
        Me.Button32.Text = "N: 300"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.BackgroundImage = CType(resources.GetObject("Button19.BackgroundImage"), System.Drawing.Image)
        Me.Button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button19.Location = New System.Drawing.Point(499, 251)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(117, 68)
        Me.Button19.TabIndex = 18
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.BackgroundImage = CType(resources.GetObject("Button13.BackgroundImage"), System.Drawing.Image)
        Me.Button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button13.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(32, 252)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(115, 68)
        Me.Button13.TabIndex = 18
        Me.Button13.Text = "N: 170"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.BackgroundImage = CType(resources.GetObject("Button17.BackgroundImage"), System.Drawing.Image)
        Me.Button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button17.Location = New System.Drawing.Point(499, 169)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(117, 77)
        Me.Button17.TabIndex = 18
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.BackgroundImage = CType(resources.GetObject("Button29.BackgroundImage"), System.Drawing.Image)
        Me.Button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button29.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.ForeColor = System.Drawing.SystemColors.Info
        Me.Button29.Location = New System.Drawing.Point(188, 88)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(111, 75)
        Me.Button29.TabIndex = 16
        Me.Button29.Text = "N: 250"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.BackgroundImage = CType(resources.GetObject("Button31.BackgroundImage"), System.Drawing.Image)
        Me.Button31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button31.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.Location = New System.Drawing.Point(32, 169)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(115, 77)
        Me.Button31.TabIndex = 18
        Me.Button31.Text = "N: 65"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.BackgroundImage = CType(resources.GetObject("Button30.BackgroundImage"), System.Drawing.Image)
        Me.Button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button30.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.Location = New System.Drawing.Point(336, 88)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(118, 75)
        Me.Button30.TabIndex = 17
        Me.Button30.Text = "N: 350"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.Button16)
        Me.Panel3.Controls.Add(Me.Label18)
        Me.Panel3.Controls.Add(Me.TextBox1)
        Me.Panel3.Controls.Add(Me.Panel6)
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Location = New System.Drawing.Point(2, 536)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1364, 170)
        Me.Panel3.TabIndex = 0
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.Red
        Me.Button16.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(1226, 112)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(70, 37)
        Me.Button16.TabIndex = 33
        Me.Button16.Text = "Back"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Lucida Sans", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(1163, 9)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(133, 31)
        Me.Label18.TabIndex = 5
        Me.Label18.Text = "On Duty"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Lucida Sans", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(1159, 47)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(185, 53)
        Me.TextBox1.TabIndex = 4
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.Button46)
        Me.Panel6.Controls.Add(Me.Button45)
        Me.Panel6.Controls.Add(Me.Button44)
        Me.Panel6.Controls.Add(Me.Button43)
        Me.Panel6.Location = New System.Drawing.Point(822, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(331, 160)
        Me.Panel6.TabIndex = 0
        '
        'Button46
        '
        Me.Button46.Location = New System.Drawing.Point(167, 83)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(138, 58)
        Me.Button46.TabIndex = 3
        Me.Button46.Text = "Remove Item"
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Button45
        '
        Me.Button45.Location = New System.Drawing.Point(23, 83)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(138, 58)
        Me.Button45.TabIndex = 2
        Me.Button45.Text = "Print"
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.Location = New System.Drawing.Point(167, 4)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(138, 58)
        Me.Button44.TabIndex = 1
        Me.Button44.Text = "Reset"
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.Location = New System.Drawing.Point(23, 3)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(138, 58)
        Me.Button43.TabIndex = 0
        Me.Button43.Text = "Pay"
        Me.Button43.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.label4)
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Controls.Add(Me.Label1)
        Me.Panel5.Controls.Add(Me.ComboBox1)
        Me.Panel5.Location = New System.Drawing.Point(390, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(423, 160)
        Me.Panel5.TabIndex = 0
        '
        'label4
        '
        Me.label4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.label4.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(209, 62)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(194, 25)
        Me.label4.TabIndex = 6
        Me.label4.Text = "0"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Location = New System.Drawing.Point(209, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(194, 28)
        Me.Label5.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Lucida Sans Typewriter", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(31, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 23)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Change"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Lucida Sans Unicode", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(36, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 25)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Cost"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Lucida Sans Unicode", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(198, 25)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Payment Method"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(209, 10)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(194, 26)
        Me.ComboBox1.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Silver
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.Label11)
        Me.Panel4.Controls.Add(Me.Label10)
        Me.Panel4.Controls.Add(Me.Label7)
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Controls.Add(Me.Label8)
        Me.Panel4.Location = New System.Drawing.Point(8, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(364, 160)
        Me.Panel4.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(164, 67)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(179, 28)
        Me.Label9.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Location = New System.Drawing.Point(164, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(179, 28)
        Me.Label11.TabIndex = 6
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label10.Location = New System.Drawing.Point(164, 116)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(179, 28)
        Me.Label10.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Lucida Sans Unicode", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(36, 66)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 25)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Taxt"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Lucida Sans Unicode", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(6, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(122, 25)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Sub-Total"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Lucida Sans Typewriter", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(31, 116)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(75, 23)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Total"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Algerian", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(233, 9)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(686, 30)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "ACE MALL POINT OF SALES MANAGEMENT SYSTEM"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(1033, 30)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(164, 26)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "CATEGORIES"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(788, 52)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(146, 26)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "GROCERIES"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(1212, 52)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(111, 26)
        Me.Label15.TabIndex = 4
        Me.Label15.Text = "BEAUTY"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(432, 52)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(212, 26)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "SELECTED ITEMS"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(65, 52)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(125, 26)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "NUMBERS"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(1030, 712)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(328, 26)
        Me.DateTimePicker1.TabIndex = 7
        '
        'Button47
        '
        Me.Button47.BackgroundImage = CType(resources.GetObject("Button47.BackgroundImage"), System.Drawing.Image)
        Me.Button47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button47.Location = New System.Drawing.Point(1309, 8)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(49, 31)
        Me.Button47.TabIndex = 8
        Me.Button47.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'SalesreportBindingSource
        '
        Me.SalesreportBindingSource.DataMember = "sales_report"
        Me.SalesreportBindingSource.DataSource = Me.PointofsalesDataSet
        '
        'PointofsalesDataSet
        '
        Me.PointofsalesDataSet.DataSetName = "pointofsalesDataSet"
        Me.PointofsalesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Sales_reportTableAdapter
        '
        Me.Sales_reportTableAdapter.ClearBeforeFill = True
        '
        'PointofsalesDataSet1
        '
        Me.PointofsalesDataSet1.DataSetName = "pointofsalesDataSet1"
        Me.PointofsalesDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SalesreportBindingSource1
        '
        Me.SalesreportBindingSource1.DataMember = "sales_report"
        Me.SalesreportBindingSource1.DataSource = Me.PointofsalesDataSet1
        '
        'Sales_reportTableAdapter1
        '
        Me.Sales_reportTableAdapter1.ClearBeforeFill = True
        '
        'PointofsalesDataSet2
        '
        Me.PointofsalesDataSet2.DataSetName = "pointofsalesDataSet2"
        Me.PointofsalesDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SalesreportBindingSource2
        '
        Me.SalesreportBindingSource2.DataMember = "sales_report"
        Me.SalesreportBindingSource2.DataSource = Me.PointofsalesDataSet2
        '
        'Sales_reportTableAdapter2
        '
        Me.Sales_reportTableAdapter2.ClearBeforeFill = True
        '
        'UpdateOrderOptionBindingSource
        '
        Me.UpdateOrderOptionBindingSource.DataSource = GetType(POS_second_idea.pointofsalesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption)
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Items, Me.Qunti, Me.Amount})
        Me.ListView1.Location = New System.Drawing.Point(374, 345)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(197, 128)
        Me.ListView1.TabIndex = 9
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'Items
        '
        Me.Items.Text = "Items"
        '
        'Qunti
        '
        Me.Qunti.Text = ""
        '
        'Amount
        '
        Me.Amount.Text = ""
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ItemsList, Me.Quantity, Me.Amounts})
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.Location = New System.Drawing.Point(344, 91)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.Size = New System.Drawing.Size(364, 435)
        Me.DataGridView1.TabIndex = 10
        '
        'ItemsList
        '
        Me.ItemsList.HeaderText = "ItemsList"
        Me.ItemsList.Name = "ItemsList"
        '
        'Quantity
        '
        Me.Quantity.HeaderText = "Quantity"
        Me.Quantity.Name = "Quantity"
        '
        'Amounts
        '
        Me.Amounts.HeaderText = "Amounts"
        Me.Amounts.Name = "Amounts"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Lime
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.Button47)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.SalesreportBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PointofsalesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PointofsalesDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SalesreportBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PointofsalesDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SalesreportBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpdateOrderOptionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button12 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button36 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Button39 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Button46 As Button
    Friend WithEvents Button45 As Button
    Friend WithEvents Button44 As Button
    Friend WithEvents Button43 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Button47 As Button
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents Label18 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents PointofsalesDataSet As pointofsalesDataSet
    Friend WithEvents SalesreportBindingSource As BindingSource
    Friend WithEvents Sales_reportTableAdapter As pointofsalesDataSetTableAdapters.sales_reportTableAdapter
    Friend WithEvents PointofsalesDataSet1 As pointofsalesDataSet1
    Friend WithEvents SalesreportBindingSource1 As BindingSource
    Friend WithEvents Sales_reportTableAdapter1 As pointofsalesDataSet1TableAdapters.sales_reportTableAdapter
    Friend WithEvents PointofsalesDataSet2 As pointofsalesDataSet2
    Friend WithEvents SalesreportBindingSource2 As BindingSource
    Friend WithEvents Sales_reportTableAdapter2 As pointofsalesDataSet2TableAdapters.sales_reportTableAdapter
    Friend WithEvents UpdateOrderOptionBindingSource As BindingSource
    Friend WithEvents ListView1 As ListView
    Friend WithEvents Items As ColumnHeader
    Friend WithEvents Qunti As ColumnHeader
    Friend WithEvents Amount As ColumnHeader
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ItemsList As DataGridViewTextBoxColumn
    Friend WithEvents Quantity As DataGridViewTextBoxColumn
    Friend WithEvents Amounts As DataGridViewTextBoxColumn
    Friend WithEvents Button16 As Button
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents label4 As TextBox
End Class
